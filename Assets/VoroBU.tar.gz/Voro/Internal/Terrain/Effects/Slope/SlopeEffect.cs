using Voro.Internal.Terrain.Algorithms.Slope;
using Voro.Internal.Terrain.Attributes;

namespace Voro.Internal.Terrain.Effects.Slope {
[Effect(typeof(SlopeAlgorithm),"Linear Gradient")]
public class SlopeEffect : TerrainEffect { }
}