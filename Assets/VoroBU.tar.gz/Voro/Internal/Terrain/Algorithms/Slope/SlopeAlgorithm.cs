using Voro.Internal.Terrain.Attributes;

namespace Voro.Internal.Terrain.Algorithms.Slope {
[Algorithm()]
public class SlopeAlgorithm : TerrainAlgorithm { }
}