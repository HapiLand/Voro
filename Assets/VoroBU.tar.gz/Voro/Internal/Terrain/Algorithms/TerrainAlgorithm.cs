using UnityEngine;

namespace Voro.Internal.Terrain.Algorithms {
/// <summary>
/// Shader Function
/// <example> Noise Shader </example>
/// <example> Slope Shader </example>
/// </summary>
public abstract class TerrainAlgorithm : ScriptableObject {
  public string title;
}
}