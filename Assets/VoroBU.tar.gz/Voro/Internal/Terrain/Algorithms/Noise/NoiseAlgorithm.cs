using Voro.Internal.Terrain.Attributes;

namespace Voro.Internal.Terrain.Algorithms.Noise {
[Algorithm()]
public class NoiseAlgorithm : TerrainAlgorithm { }
}