using System;

namespace Voro.Internal.Terrain.Attributes {
[AttributeUsage(AttributeTargets.Class)]
public class AlgorithmAttribute : Attribute {
  public readonly string KernelID;
  public AlgorithmAttribute(string kernelID = "CSMain") {
    KernelID = kernelID;
  }
}
}