using UnityEditor;

namespace Voro.UserInterface.Builders.AlgorithmBuilder.Editor {
public static class AlgorithmBuilderMenuItem {
  [MenuItem("Voro/User Interface/Algorithm Builder")]
  public static void OpenWindow() {
    AlgorithmBuilderEditorWindow.ShowWindow();
  }
}
}