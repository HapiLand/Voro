using UnityEditor;
using UnityEngine;

namespace Voro.UserInterface.Builders.AlgorithmBuilder.Editor {
public class AlgorithmBuilderEditorWindow : EditorWindow {
  const string WindowTitle = "Algorithm Builder";
  static readonly Vector2 WindowSize = new (640, 480);

  void OnGUI() {
    
  }
  
  public static void ShowWindow() {
    var wnd = GetWindow<AlgorithmBuilderEditorWindow>();
    wnd.titleContent = new GUIContent(WindowTitle);
    wnd.minSize = WindowSize;
    wnd.maxSize = WindowSize;
    wnd.Show();
  }
}
}