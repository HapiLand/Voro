using System.Collections.Generic;
using UnityEngine;

public static class InstanceHelper
{
    public static T LoadAndInstancePrefab<T>(string path) where T : UnityEngine.Object
    {
        T prefab = Resources.Load<T>(path);
        return Object.Instantiate(prefab) as T;
    }

}
