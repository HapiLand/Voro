using System;
using UnityEngine;

public static class JsonHelper
{
    public static T LoadResource<T>(string path) where T : UnityEngine.Object
    {
        return Resources.Load<T>(path);
    }

}
