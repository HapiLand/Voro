using System;

namespace Objects {
[Serializable]
public struct VoroParameters {
    public string JSONPath; // point table 
    
    // height parameters
    // slope
    public float SlopeScale;
    // noise
    public float NoiseSize;
    public float NoiseScale;
    // terrace
    public int TerraceIterations;
    public float TerraceMin;
    public float TerraceMax;
    public int TerraceSeed;
    public float TerraceScale;
    public float TerraceTilt;
}
}