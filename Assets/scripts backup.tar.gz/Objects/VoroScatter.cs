using System;
using System.Collections.Generic;
using UnityEngine;

namespace Objects {
/// <summary>
/// places points in the grid
/// </summary>
[Serializable]
public class VoroScatter {
    public static VoroScatter CreateInstance() {
        return new VoroScatter();
    }

    public void GeneratePoints(VoroParameters param, Vector3 offset, out Point[] outPoints) {
        // create each point in the json
        TextAsset json = JsonHelper.LoadResource<TextAsset>(param.JSONPath);
        PointTable jsonTable = JsonUtility.FromJson<PointTable>(json.text);
        // load the data from the json to find all the points it has
        outPoints = new Point[jsonTable.points.Length];
        outPoints = jsonTable.points;
        
        // offset the position for these points
        for (int i = 0; i < outPoints.Length; i++) {
            //var point = outPoints[i];

            // offset has to be swizzled as the axis of the json points
            // is different to unity
            // json points = XYZ
            // unity = XYZ
            float x = outPoints[i].p[0] + offset.z;
            float z = outPoints[i].p[1] + offset.x;
            // probably does not need to be fixed, it doesnt cause any problems

            outPoints[i].p = new float[2] { x, z };
            
            /*Point newPoint = new Point()
            {
                id = point.id,
                height = point.height,
                p = new float[2] { x, z }
            };
            
            result[i] = newPoint;*/
        }
    }
    
    /// <summary>
    /// offsets the position of the points to match the parent object
    /// </summary>
    /*void OffsetPosition(Vector3 offset, Point[] oldPoints) {

        Point[] result = new Point[TablePoints.Length];

        for (int i = 0; i < TablePoints.Length; i++) {
            var point = TablePoints[i];

            // offset has to be swizzled as the axis of the json points
            // is different to unity
            // json points = XYZ
            // unity = XYZ
            float x = point.p[0] + offset.z;
            float z = point.p[1] + offset.x;
            // probably does not need to be fixed, it doesnt cause any problems
            
            Point newPoint = new Point()
            {
                id = point.id,
                height = point.height,
                p = new float[2] { x, z }
            };
            
            result[i] = newPoint;
        }

        TablePoints = result;
    }*/
}
}