using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Objects {
/// <summary>
/// sets the height attribute on the points
/// </summary>
[Serializable]
public class VoroHeight {
    
    public static VoroHeight CreateInstance() {
        return new VoroHeight();
    }

    public Point[] SetHeight(Point[] points, VoroParameters param) {
        
        Point[] result = new Point[points.Length];

        for (int i = 0; i < points.Length; i++) {
            var point = points[i];
            
            float x = point.p[0];
            float z = point.p[1];

            Point newPoint = new Point()
            {
                id = point.id,
                height = GetHeightValue(point.Position,param),
                p = new float[2] { x, z }
            };
            
            result[i] = newPoint;
        }

        return result;

        float GetHeightValue(Vector3 worldPos, VoroParameters param) {
            
            float height = 0f;
            
            // add linear gradient
            height += Slope();
            float Slope() {
                float slope = worldPos.x;
                return slope * param.SlopeScale;
            }
            
            // subtract noise
            height -= Noise();
            float Noise() {
                Perlin perlin = new Perlin();
                double dx = Mathf.Abs(worldPos.x * param.NoiseSize);
                double dy = Mathf.Abs(worldPos.y * param.NoiseSize);
                double dz = Mathf.Abs(worldPos.z * param.NoiseSize);
                double noise = perlin.Noise(dx, dy, dz);
                noise *= (double)param.NoiseScale;
                return (float)noise;
            }
            
            // add terrace
            height += Terrace(); // produces height range [0,2]
            height *= 0.5f; // correct the height scale back to [0,1]
            float Terrace()
            {
                float radians = param.TerraceTilt * Mathf.Deg2Rad;
                Vector2 axis = new Vector2(Mathf.Cos(radians), Mathf.Sin(radians));
                Vector2 pos = new Vector2(worldPos.x, worldPos.z);
                float terraceHeight = Vector2.Dot(pos, axis);
                float h = terraceHeight;
                float div = h / param.TerraceScale;
                float flat = Mathf.Floor(div);
                Random.InitState(Mathf.RoundToInt(flat) + param.TerraceSeed);
                float val = Random.value;
                val = fit01(val, param.TerraceMin, param.TerraceMax) * param.TerraceIterations;
                float fit01(float value, float newMin, float newMax) {
                    return value * (newMax - newMin) + newMin;
                }
                float level = flat + val;

                return level * param.TerraceScale;
            }
            
            return height;
        }
        
    }
}
}