using System;
using UnityEngine;

namespace Objects {
public class VoroObject : MonoBehaviour {
    
    VoroParameters _param;
    [SerializeField] Voro _voro;
    void Awake() {

        // in order for a voro to be generated when needed
        // parameters and a voro instance are first constructed
        
        // parameters have information that controls the output of the voro
        GetParameterConfig();
        
        // the voro is constructed
        ConstructVoroInstance();
        
        void GetParameterConfig() {
            // default parameters
            _param = new VoroParameters()
            {
                JSONPath = "Points/Table",
                SlopeScale = 1f,
                NoiseSize = 1.25f,
                NoiseScale = 0.59f,
                TerraceIterations = 4,
                TerraceMin = 0.01f,
                TerraceMax = 0.2f,
                TerraceSeed = 0,
                TerraceScale = 0.163f,
                TerraceTilt = 41f
            };
        }
        
        void ConstructVoroInstance() {
            _voro = new Voro(_param, transform.position);
        }
    }

    void Start() {

        // generate game objects
        Cell[] cellInstances;
        _voro.Generate(out cellInstances);

        foreach (var geo in cellInstances) {
            geo.transform.SetParent(transform);
        }
    }

    void Update() {
        _voro.Update();
    }

    void OnDrawGizmos() {
        if (!Application.isPlaying) {
            return;
        }

        foreach (var point in _voro.VoroPoints) {
            Gizmos.color = Color.honeydew;
            Gizmos.DrawWireSphere(point.Position, 0.001f);
        }
    }
}
}