using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Objects {
/// <summary>
/// produces the extruded geometry
/// </summary>
[Serializable]
public class VoroGeo {
    public static VoroGeo CreateInstance() {
        return new VoroGeo();
    }
    
    public Cell[] CreateCellObjects(Point[] points) {

        Cell[] result = new Cell[points.Length];

        for (int i = 0; i < points.Length; i++) {
            //var point = points[i];
            
            Cell cellInstance = InstanceHelper.LoadAndInstancePrefab<Cell>($"Prefabs/Cell");
            cellInstance.CellPoint = points[i];
            cellInstance.transform.position = points[i].Position;
            
            result[i] = cellInstance;
        }

        return result;
    }
}
}