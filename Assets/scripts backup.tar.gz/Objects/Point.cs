using System;
using UnityEngine;

namespace Objects {
[Serializable]
public class Point {
    public int id;
    public float[] p;
    public float height;
    
    public Vector3 Position => new Vector3(p[1], height, p[0]);
}

[Serializable]
public class PointTable {
    public Point[] points;
}
}