using System;
using Interface;
using UnityEngine;

namespace Objects {
[Serializable]
public class Voro : IVoro {
    Vector3 _origin;
    VoroParameters _param;

    // the Voro classes are an abstract idea of how the actual solution runs
    // each class will be responsible for interacting with the World namespace
    // as World classes are what actually generate unity objects
    public VoroScatter Scatter { get; }
    public VoroHeight Height { get; }
    public VoroGeo Geo { get; }
    
    // the voro should contain the collection of Points
    public Point[] VoroPoints;

    public Voro(VoroParameters param, Vector3 origin) {
        SetParameters(param, origin);
        
        Scatter = ScatterPoints();
        Height = SetHeight();
        Geo = CreateGeo();
    }

    public void SetParameters(VoroParameters param, Vector3 origin) {
        _origin = origin;
        _param = param;
    }

    VoroScatter ScatterPoints() {
        // deserialize a json file to get point data
        // group and keep a region of these points
        return VoroScatter.CreateInstance();
    }

    VoroHeight SetHeight() {
        // use the coordinate of a point to look up its height
        // set the new position of the points, and correct any problems
        return VoroHeight.CreateInstance();
    }

    VoroGeo CreateGeo() {
        // produce the game objects that contain the geometry
        // at a point look up what mesh exists there and create it
        return VoroGeo.CreateInstance();
    }

    public void Generate(out Cell[] outCells) {

        // 1) deserialize the point data
        // scatter will create an array of Points (xz,id) from a json table
        Scatter.GeneratePoints(_param, _origin, out VoroPoints);

        // 2) set the height of the points
        //Scatter.TablePoints = Height.SetHeight(Scatter.TablePoints, _param);
        // this should be called in update
        
        // 3) create mesh objects for each point
        outCells = Geo.CreateCellObjects(VoroPoints);
    }

    public void Update() {
        //VoroPoints[0].height = 5f;
    }

    public void Destroy() {
        throw new System.NotImplementedException();
    }
}
}