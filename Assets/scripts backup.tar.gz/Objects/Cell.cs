using System;
using UnityEngine;
using Random = UnityEngine.Random;

namespace Objects {
public class Cell : MonoBehaviour {
    public Point CellPoint;

    void Start() {
        InstanceFBX();
    }

    void Update() {
        CellPoint.height = 5f;
    }

    void InstanceFBX() {
        
        int variantCount = 1;
        int variant = Random.Range(0, variantCount);
        GameObject fbxInstance = InstanceHelper.LoadAndInstancePrefab<GameObject>($"FBX/{CellPoint.id}_{variant}");

        fbxInstance.transform.position = CellPoint.Position;
        fbxInstance.transform.SetParent(transform);
            
        // set color
        Material mat = fbxInstance.GetComponent<MeshRenderer>().material;
        float t = Mathf.Abs(fbxInstance.transform.position.y) % 1;
        mat.color = Color.Lerp(Color.cornflowerBlue, Color.crimson, t);
        MeshRenderer renderer = fbxInstance.GetComponent<MeshRenderer>();
        renderer.material = mat;
    }
}
}