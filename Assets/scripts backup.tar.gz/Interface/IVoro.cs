using Objects;
using UnityEngine;

namespace Interface
{
    public interface IVoro
    {
        public VoroScatter Scatter { get; }
        public VoroHeight Height { get; }
        public VoroGeo Geo { get; }
        
        void SetParameters(VoroParameters param, Vector3 origin);
        void Generate(out Cell[] outCells);
        void Update();
        void Destroy();
    }
}